<?php

//connection variables
$host = 'localhost';
$user = 'registeredUser';
$password = 'password';

//create mysql connection
$mysqli = new mysqli($host,$user,$password);
if ($mysqli->connect_errno) {
    printf("Connection failed: %s\n", $mysqli->connect_error);
    die();
}
printf("Succesfull Connection");

