<?php
/* Database connection settings */
$host = 'localhost';
$user = 'registeredUser';
$pass = 'password';
$db = 'regLogin';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);


//create mysql connection
if ($mysqli->connect_errno) {
    printf("Connection failed: %s\n", $mysqli->connect_error);
    die();
}

